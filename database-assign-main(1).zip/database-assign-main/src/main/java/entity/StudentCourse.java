// StudentCourse.java
package entity;

import annotations.Table;
import lombok.*;

@Table(tableName = "student_course")
//@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentCourse {
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public Integer getCourseId() {
        return courseId;
    }

    public void setCourseId(Integer courseId) {
        this.courseId = courseId;
    }

    public Double getScore() {
        return score;
    }

    public void setScore(Double score) {
        this.score = score;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    private Integer id;
    private Integer studentId;
    private Integer courseId;
    private Double score;
    private String semester;

    @Override
    public String toString() {
        return "StudentCourse{" +
                "id=" + id +
                ", studentId=" + studentId +
                ", courseId=" + courseId +
                ", score=" + score +
                ", semester='" + semester + '\'' +
                '}';
    }
}