/*
 Navicat Premium Dump SQL

 Source Server         : 阿里云
 Source Server Type    : MySQL
 Source Server Version : 80041 (8.0.41)
 Source Host           : 123.57.221.79:3306
 Source Schema         : jsp_servlet_course

 Target Server Type    : MySQL
 Target Server Version : 80041 (8.0.41)
 File Encoding         : 65001

 Date: 19/05/2025 17:06:46
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for course
-- ----------------------------
DROP TABLE IF EXISTS `course`;
CREATE TABLE `course`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '课程ID',
  `teacher_id` bigint UNSIGNED NOT NULL COMMENT '教师ID（逻辑外键）',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT '课程名称',
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL COMMENT '课程简介',
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL DEFAULT NULL COMMENT '上课地点',
  `start_time` datetime NULL DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime NULL DEFAULT NULL COMMENT '结束时间',
  `status` enum('waitCheck','published','notPass') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL DEFAULT 'waitCheck' COMMENT '课程状态',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 26 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_520_ci COMMENT = '课程表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of course
-- ----------------------------
INSERT INTO `course` VALUES (12, 13, 'dfsdsgffdg', 't454ty646', 'kkjhkjkljlkjj', '2025-05-17 16:58:00', '2025-05-17 16:58:00', 'published', '2025-05-18 00:58:31', '2025-05-18 01:54:54');
INSERT INTO `course` VALUES (13, 13, 'dfsdsgffdg', '334444', 'kkjhkjkljlkj', '2025-05-18 01:19:00', '2025-05-18 01:19:00', 'published', '2025-05-18 01:20:01', '2025-05-18 01:24:35');
INSERT INTO `course` VALUES (14, 13, 'dfsdsgffdg', 'jhkhkhj', 'kjhkhkjh', '2025-05-18 01:54:00', '2025-05-18 01:54:00', 'waitCheck', '2025-05-18 01:54:45', '2025-05-18 01:54:45');
INSERT INTO `course` VALUES (15, 101, 'Introduction to Computer Science', 'An introductory course to computer science fundamentals.', 'Building A, Room 101', '2025-09-01 09:00:00', '2025-12-15 11:00:00', 'published', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (16, 102, 'Advanced Mathematics', 'Covers advanced topics in calculus and linear algebra.', 'Science Center, Hall B', '2025-09-03 10:00:00', '2025-12-17 12:00:00', 'waitCheck', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (17, 103, 'English Literature', 'Exploration of classic and modern literature.', 'Library Annex, Room 204', '2025-09-05 13:00:00', '2025-12-19 15:00:00', 'notPass', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (18, 104, 'Physics Fundamentals', 'Basic principles of physics including mechanics and thermodynamics.', 'Lab Complex, Room 302', '2025-09-08 08:30:00', '2025-12-20 10:30:00', 'published', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (19, 105, 'Economics Principles', 'An overview of microeconomics and macroeconomics.', 'Business School, Room 105', '2025-09-10 14:00:00', '2025-12-22 16:00:00', 'waitCheck', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (20, 106, 'History of Art', 'A survey of art history from ancient times to the modern era.', 'Museum Hall, Room 1', '2025-09-12 11:00:00', '2025-12-24 13:00:00', 'published', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (21, 107, 'Chemistry Basics', 'Introductory chemistry covering atoms, molecules, and reactions.', 'Chem Lab, Room 401', '2025-09-15 09:30:00', '2025-12-27 11:30:00', 'published', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (22, 108, 'Biology Concepts', 'Fundamental concepts in biology including cell structure and genetics.', 'Bio Lab, Room 201', '2025-09-18 10:00:00', '2025-12-30 12:00:00', 'waitCheck', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (23, 109, 'Modern Philosophy', 'Study of philosophical ideas from the 17th century to today.', 'Philosophy Building, Room 303', '2025-09-20 15:00:00', '2025-12-31 17:00:00', 'notPass', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (24, 110, 'Data Structures and Algorithms', 'In-depth study of data structures and algorithm design.', 'Building C, Room 404', '2026-01-05 09:00:00', '2026-04-10 11:00:00', 'published', '2025-05-18 11:13:28', '2025-05-18 11:13:28');
INSERT INTO `course` VALUES (25, 13, 'english', 'test', 'test', '2025-05-18 11:16:00', '2025-05-18 11:16:00', 'published', '2025-05-18 11:16:55', '2025-05-18 11:17:15');

-- ----------------------------
-- Table structure for personal_info
-- ----------------------------
DROP TABLE IF EXISTS `personal_info`;
CREATE TABLE `personal_info`  (
  `user_id` bigint UNSIGNED NOT NULL COMMENT '用户ID（逻辑外键）',
  `department` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL DEFAULT NULL COMMENT '院系（针对学生）',
  `major` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL DEFAULT NULL COMMENT '专业（针对学生）',
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL DEFAULT NULL COMMENT '职称（针对教师）',
  `office_location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL DEFAULT NULL COMMENT '办公室位置（针对教师）',
  PRIMARY KEY (`user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_520_ci COMMENT = '个人信息表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of personal_info
-- ----------------------------
INSERT INTO `personal_info` VALUES (11, 'School of Engineering', 'Computer Science', NULL, NULL);
INSERT INTO `personal_info` VALUES (13, NULL, NULL, 'Professor of Physics', 'Science Building, Room 505');

-- ----------------------------
-- Table structure for student_course
-- ----------------------------
DROP TABLE IF EXISTS `student_course`;
CREATE TABLE `student_course`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '选课记录ID',
  `student_id` bigint UNSIGNED NOT NULL COMMENT '学生ID（逻辑外键）',
  `course_id` bigint UNSIGNED NOT NULL COMMENT '课程ID（逻辑外键）',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '选课时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 13 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_520_ci COMMENT = '学生选课表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of student_course
-- ----------------------------
INSERT INTO `student_course` VALUES (12, 11, 15, '2025-05-18 11:15:52');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT '用户名',
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT '密码',
  `role` enum('student','teacher','admin') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'student' COMMENT '用户角色',
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NOT NULL COMMENT '邮箱',
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_520_ci NULL DEFAULT NULL COMMENT '联系电话',
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `email`(`email` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 14 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_520_ci COMMENT = '用户表' ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (11, 'test', '123456', 'student', '2694193104@qq.com', '18364073152', '2025-05-17 21:37:20', '2025-05-17 21:37:20');
INSERT INTO `user` VALUES (12, 'a', '123456', 'admin', '793686633%40qq.com', '18364073152', '2025-05-17 23:57:34', '2025-05-18 01:10:01');
INSERT INTO `user` VALUES (13, 't', '123456', 'teacher', '1456161@qq.com', '18364073152', '2025-05-18 00:52:08', '2025-05-18 00:52:08');

SET FOREIGN_KEY_CHECKS = 1;
