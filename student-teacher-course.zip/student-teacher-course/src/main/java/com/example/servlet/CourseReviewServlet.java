package com.example.servlet;

import com.example.dao.CourseDao;
import com.example.entity.Course;
import com.google.gson.Gson;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/api/course/review")
public class CourseReviewServlet extends HttpServlet {
    private CourseDao courseDao;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        courseDao = new CourseDao();
        gson = new Gson();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            // 检查用户是否是管理员
            if (!isAdmin(request)) {
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                result.put("success", false);
                result.put("message", "只有管理员可以审核课程");
                out.print(gson.toJson(result));
                return;
            }

            // 获取请求参数
            Long courseId = Long.parseLong(request.getParameter("courseId"));
            String status = request.getParameter("status");

            // 验证状态值
            if (!isValidStatus(status)) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                result.put("success", false);
                result.put("message", "无效的课程状态");
                out.print(gson.toJson(result));
                return;
            }

            // 更新课程状态
            Course course = new Course();
            course.setId(courseId);
            course.setStatus(status);
            
            int rows = courseDao.updateStatus(course);
            
            if (rows > 0) {
                result.put("success", true);
                result.put("message", "课程状态更新成功");
            } else {
                result.put("success", false);
                result.put("message", "课程状态更新失败");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.put("success", false);
            result.put("message", "服务器错误: " + e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    private boolean isAdmin(HttpServletRequest request) {
        // TODO: 实现管理员权限检查
        // 这里需要根据你的用户认证系统来实现
        return true;
    }

    private boolean isValidStatus(String status) {
        return status != null && 
               (status.equals("published") || 
                status.equals("notPass") || 
                status.equals("waitCheck"));
    }
} 