package com.example.servlet;

import com.example.dao.CourseDao;
import com.example.entity.Course;
import com.google.gson.Gson;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/api/course/*")
public class CourseServlet extends HttpServlet {
    private CourseDao courseDao = new CourseDao();
    private Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // 获取所有课程
                List<Course> courses = courseDao.selectAll();
                result.put("code", 200);
                result.put("data", courses);
            } else if (pathInfo.startsWith("/teacher/")) {
                // 根据教师ID查询课程
                Long teacherId = Long.parseLong(pathInfo.substring(9));
                List<Course> courses = courseDao.selectByTeacherId(teacherId);
                result.put("code", 200);
                result.put("data", courses);
            } else {
                // 根据ID查询单个课程
                Long id = Long.parseLong(pathInfo.substring(1));
                Course course = courseDao.selectById(id);
                if (course != null) {
                    result.put("code", 200);
                    result.put("data", course);
                } else {
                    result.put("code", 404);
                    result.put("message", "课程不存在");
                }
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "服务器错误：" + e.getMessage());
        }
        out.print(gson.toJson(result));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            Course course = gson.fromJson(request.getReader(), Course.class);
            course.setCreateTime(new Timestamp(System.currentTimeMillis()));
            course.setUpdateTime(new Timestamp(System.currentTimeMillis()));
            
            int rows = courseDao.insert(course);
            if (rows > 0) {
                result.put("code", 200);
                result.put("message", "添加成功");
            } else {
                result.put("code", 500);
                result.put("message", "添加失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "服务器错误：" + e.getMessage());
        }
        out.print(gson.toJson(result));
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            Course course = gson.fromJson(request.getReader(), Course.class);
            course.setUpdateTime(new Timestamp(System.currentTimeMillis()));
            
            int rows = courseDao.update(course);
            if (rows > 0) {
                result.put("code", 200);
                result.put("message", "更新成功");
            } else {
                result.put("code", 500);
                result.put("message", "更新失败");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "服务器错误：" + e.getMessage());
        }
        out.print(gson.toJson(result));
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            String pathInfo = request.getPathInfo();
            if (pathInfo != null && !pathInfo.equals("/")) {
                Long id = Long.parseLong(pathInfo.substring(1));
                int rows = courseDao.deleteById(id);
                if (rows > 0) {
                    result.put("code", 200);
                    result.put("message", "删除成功");
                } else {
                    result.put("code", 404);
                    result.put("message", "课程不存在");
                }
            } else {
                result.put("code", 400);
                result.put("message", "缺少课程ID");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "服务器错误：" + e.getMessage());
        }
        out.print(gson.toJson(result));
    }
} 