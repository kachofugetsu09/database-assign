package com.example.servlet;

import com.example.dao.PersonalInfoDao;
import com.example.entity.PersonalInfo;
import com.google.gson.Gson;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/api/personal-info/*")
public class PersonalInfoServlet extends HttpServlet {
    private PersonalInfoDao personalInfoDao;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        personalInfoDao = new PersonalInfoDao();
        gson = new Gson();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json;charset=UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if ("/user".equals(pathInfo)) {
                // 获取用户信息
                Long userId = Long.parseLong(request.getParameter("userId"));
                PersonalInfo personalInfo = personalInfoDao.selectByUserId(userId);
                
                if (personalInfo != null) {
                    result.put("success", true);
                    result.put("data", personalInfo);
                } else {
                    result.put("success", false);
                    result.put("message", "Personal information not found");
                }
            } else if ("/add".equals(pathInfo)) {
                // Add personal information
                Long userId = Long.parseLong(request.getParameter("userId"));
                String department = request.getParameter("department");
                String major = request.getParameter("major");
                String title = request.getParameter("title");
                String officeLocation = request.getParameter("officeLocation");

                PersonalInfo personalInfo = new PersonalInfo();
                personalInfo.setUserId(userId);
                personalInfo.setDepartment(department);
                personalInfo.setMajor(major);
                personalInfo.setTitle(title);
                personalInfo.setOfficeLocation(officeLocation);

                int rows = personalInfoDao.insert(personalInfo);
                result.put("success", rows > 0);
                result.put("message", rows > 0 ? "Added successfully" : "Failed to add");
            } else if ("/update".equals(pathInfo)) {
                // Update personal information
                Long userId = Long.parseLong(request.getParameter("userId"));
                String department = request.getParameter("department");
                String major = request.getParameter("major");
                String title = request.getParameter("title");
                String officeLocation = request.getParameter("officeLocation");

                PersonalInfo personalInfo = new PersonalInfo();
                personalInfo.setUserId(userId);
                personalInfo.setDepartment(department);
                personalInfo.setMajor(major);
                personalInfo.setTitle(title);
                personalInfo.setOfficeLocation(officeLocation);

                int rows = personalInfoDao.update(personalInfo);
                result.put("success", rows > 0);
                result.put("message", rows > 0 ? "Updated successfully" : "Failed to update");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                result.put("success", false);
                result.put("message", "Invalid request path");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.put("success", false);
            result.put("message", "Server error: " + e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
} 