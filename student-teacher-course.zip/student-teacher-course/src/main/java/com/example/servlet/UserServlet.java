package com.example.servlet;

import com.example.dao.UserDao;
import com.example.entity.User;
import com.google.gson.Gson;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/api/user/*")
public class UserServlet extends HttpServlet {
    private UserDao userDao = new UserDao();
    private Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if (pathInfo == null || pathInfo.equals("/")) {
                // 用户注册
                User user = gson.fromJson(request.getReader(), User.class);
                
                // 验证必填字段
                if (user.getUsername() == null || user.getPassword() == null || 
                    user.getEmail() == null || user.getRole() == null) {
                    result.put("code", 400);
                    result.put("message", "用户名、密码、邮箱和角色不能为空");
                    out.print(gson.toJson(result));
                    return;
                }
                
                // 检查用户名是否存在
                if (userDao.isUsernameExists(user.getUsername())) {
                    result.put("code", 400);
                    result.put("message", "用户名已存在");
                    out.print(gson.toJson(result));
                    return;
                }
                
                // 检查邮箱是否存在
                if (userDao.isEmailExists(user.getEmail())) {
                    result.put("code", 400);
                    result.put("message", "邮箱已被注册");
                    out.print(gson.toJson(result));
                    return;
                }
                
                int rows = userDao.register(user);
                if (rows > 0) {
                    result.put("code", 200);
                    result.put("message", "注册成功");
                } else {
                    result.put("code", 500);
                    result.put("message", "注册失败");
                }
            } else if (pathInfo.equals("/login")) {
                // 用户登录
                Map<String, String> loginData = gson.fromJson(request.getReader(), Map.class);
                String username = loginData.get("username");
                String password = loginData.get("password");
                
                if (username == null || password == null) {
                    result.put("code", 400);
                    result.put("message", "用户名和密码不能为空");
                    out.print(gson.toJson(result));
                    return;
                }
                
                User user = userDao.login(username, password);
                if (user != null) {
                    // 登录成功，将用户信息存入session
                    HttpSession session = request.getSession();
                    session.setAttribute("user", user);
                    
                    // 返回用户信息（不包含密码）
                    user.setPassword(null);
                    result.put("code", 200);
                    result.put("message", "登录成功");
                    result.put("data", user);
                } else {
                    result.put("code", 401);
                    result.put("message", "用户名或密码错误");
                }
            } else {
                result.put("code", 404);
                result.put("message", "请求的接口不存在");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "服务器错误：" + e.getMessage());
        }
        out.print(gson.toJson(result));
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if (pathInfo != null && pathInfo.startsWith("/check/username/")) {
                // 检查用户名是否存在
                String username = pathInfo.substring(15);
                boolean exists = userDao.isUsernameExists(username);
                result.put("code", 200);
                result.put("exists", exists);
            } else if (pathInfo != null && pathInfo.startsWith("/check/email/")) {
                // 检查邮箱是否存在
                String email = pathInfo.substring(13);
                boolean exists = userDao.isEmailExists(email);
                result.put("code", 200);
                result.put("exists", exists);
            } else if (pathInfo != null && pathInfo.equals("/current")) {
                // 获取当前登录用户信息
                HttpSession session = request.getSession();
                User user = (User) session.getAttribute("user");
                if (user != null) {
                    user.setPassword(null); // 不返回密码
                    result.put("code", 200);
                    result.put("data", user);
                } else {
                    result.put("code", 401);
                    result.put("message", "未登录");
                }
            } else {
                result.put("code", 404);
                result.put("message", "请求的接口不存在");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "服务器错误：" + e.getMessage());
        }
        out.print(gson.toJson(result));
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if (pathInfo != null && pathInfo.equals("/logout")) {
                // 用户登出
                HttpSession session = request.getSession();
                session.invalidate();
                result.put("code", 200);
                result.put("message", "登出成功");
            } else {
                result.put("code", 404);
                result.put("message", "请求的接口不存在");
            }
        } catch (Exception e) {
            result.put("code", 500);
            result.put("message", "服务器错误：" + e.getMessage());
        }
        out.print(gson.toJson(result));
    }
} 