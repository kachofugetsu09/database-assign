package com.example.servlet;

import com.example.dao.StudentCourseDao;
import com.example.entity.StudentCourse;
import com.google.gson.Gson;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@WebServlet("/api/student-course/*")
public class StudentCourseServlet extends HttpServlet {
    private StudentCourseDao studentCourseDao;
    private Gson gson;

    @Override
    public void init() throws ServletException {
        studentCourseDao = new StudentCourseDao();
        gson = new Gson();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if ("/enroll".equals(pathInfo)) {
                // 学生选课
                Long studentId = Long.parseLong(request.getParameter("studentId"));
                Long courseId = Long.parseLong(request.getParameter("courseId"));

                if (studentCourseDao.isStudentEnrolled(studentId, courseId)) {
                    result.put("success", false);
                    result.put("message", "已经选过该课程");
                } else {
                    StudentCourse studentCourse = new StudentCourse();
                    studentCourse.setStudentId(studentId);
                    studentCourse.setCourseId(courseId);
                    
                    int rows = studentCourseDao.insert(studentCourse);
                    result.put("success", rows > 0);
                    result.put("message", rows > 0 ? "选课成功" : "选课失败");
                }
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                result.put("success", false);
                result.put("message", "无效的请求路径");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.put("success", false);
            result.put("message", "服务器错误: " + e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if ("/drop".equals(pathInfo)) {
                // 读取请求体内容
                StringBuilder buffer = new StringBuilder();
                BufferedReader reader = request.getReader();
                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }
                String data = buffer.toString();
                
                // 解析请求参数
                String[] params = data.split("&");
                Map<String, String> paramMap = new HashMap<>();
                for (String param : params) {
                    String[] keyValue = param.split("=");
                    if (keyValue.length == 2) {
                        paramMap.put(keyValue[0], keyValue[1]);
                    }
                }

                // 获取参数值
                String studentIdStr = paramMap.get("studentId");
                String courseIdStr = paramMap.get("courseId");

                if (studentIdStr == null || courseIdStr == null) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    result.put("success", false);
                    result.put("message", "缺少必要参数");
                    out.print(gson.toJson(result));
                    out.flush();
                    return;
                }

                Long studentId = Long.parseLong(studentIdStr);
                Long courseId = Long.parseLong(courseIdStr);

                int rows = studentCourseDao.deleteByStudentAndCourse(studentId, courseId);
                result.put("success", rows > 0);
                result.put("message", rows > 0 ? "退选成功" : "退选失败");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                result.put("success", false);
                result.put("message", "无效的请求路径");
            }
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            result.put("success", false);
            result.put("message", "参数格式错误");
        } catch (Exception e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.put("success", false);
            result.put("message", "服务器错误: " + e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Map<String, Object> result = new HashMap<>();

        try {
            if ("/student".equals(pathInfo)) {
                // 获取学生的选课列表
                Long studentId = Long.parseLong(request.getParameter("studentId"));
                List<StudentCourse> courses = studentCourseDao.selectByStudentId(studentId);
                result.put("success", true);
                result.put("data", courses);
            } else if ("/course".equals(pathInfo)) {
                // 获取课程的学生列表
                Long courseId = Long.parseLong(request.getParameter("courseId"));
                List<StudentCourse> students = studentCourseDao.selectByCourseId(courseId);
                result.put("success", true);
                result.put("data", students);
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                result.put("success", false);
                result.put("message", "无效的请求路径");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            result.put("success", false);
            result.put("message", "服务器错误: " + e.getMessage());
        }

        out.print(gson.toJson(result));
        out.flush();
    }
} 