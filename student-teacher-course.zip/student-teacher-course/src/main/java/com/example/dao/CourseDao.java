package com.example.dao;

import com.example.entity.Course;
import com.example.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDao {
    
    /**
     * 添加课程
     */
    public int insert(Course course) {
        String sql = "INSERT INTO course (teacher_id, name, description, location, start_time, end_time, status, create_time, update_time) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), NOW())";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, course.getTeacherId());
            ps.setString(2, course.getName());
            ps.setString(3, course.getDescription());
            ps.setString(4, course.getLocation());
            ps.setTimestamp(5, course.getStartTime());
            ps.setTimestamp(6, course.getEndTime());
            ps.setString(7, course.getStatus());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 根据ID删除课程
     */
    public int deleteById(Long id) {
        String sql = "DELETE FROM course WHERE id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 更新课程信息
     */
    public int update(Course course) {
        String sql = "UPDATE course SET teacher_id = ?, name = ?, description = ?, location = ?, " +
                    "start_time = ?, end_time = ?, status = ?, update_time = NOW() WHERE id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, course.getTeacherId());
            ps.setString(2, course.getName());
            ps.setString(3, course.getDescription());
            ps.setString(4, course.getLocation());
            ps.setTimestamp(5, course.getStartTime());
            ps.setTimestamp(6, course.getEndTime());
            ps.setString(7, course.getStatus());
            ps.setLong(8, course.getId());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 根据ID查询课程
     */
    public Course selectById(Long id) {
        String sql = "SELECT * FROM course WHERE id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return extractCourse(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return null;
    }
    
    /**
     * 查询所有课程
     */
    public List<Course> selectAll() {
        String sql = "SELECT * FROM course ORDER BY create_time DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Course> courses = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            while (rs.next()) {
                courses.add(extractCourse(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return courses;
    }
    
    /**
     * 根据教师ID查询课程
     */
    public List<Course> selectByTeacherId(Long teacherId) {
        String sql = "SELECT * FROM course WHERE teacher_id = ? ORDER BY create_time DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Course> courses = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, teacherId);
            rs = ps.executeQuery();
            while (rs.next()) {
                courses.add(extractCourse(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return courses;
    }
    
    /**
     * 分页查询课程
     */
    public List<Course> selectByPage(int pageNum, int pageSize) {
        String sql = "SELECT * FROM course ORDER BY create_time DESC LIMIT ?, ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Course> courses = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, (pageNum - 1) * pageSize);
            ps.setInt(2, pageSize);
            rs = ps.executeQuery();
            while (rs.next()) {
                courses.add(extractCourse(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return courses;
    }
    
    /**
     * 获取总记录数
     */
    public int selectCount() {
        String sql = "SELECT COUNT(*) FROM course";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return 0;
    }
    
    /**
     * 更新课程状态
     */
    public int updateStatus(Course course) {
        String sql = "UPDATE course SET status = ?, update_time = NOW() WHERE id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, course.getStatus());
            ps.setLong(2, course.getId());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 从ResultSet中提取Course对象
     */
    private Course extractCourse(ResultSet rs) throws SQLException {
        Course course = new Course();
        course.setId(rs.getLong("id"));
        course.setTeacherId(rs.getLong("teacher_id"));
        course.setName(rs.getString("name"));
        course.setDescription(rs.getString("description"));
        course.setLocation(rs.getString("location"));
        course.setStartTime(rs.getTimestamp("start_time"));
        course.setEndTime(rs.getTimestamp("end_time"));
        course.setStatus(rs.getString("status"));
        course.setCreateTime(rs.getTimestamp("create_time"));
        course.setUpdateTime(rs.getTimestamp("update_time"));
        return course;
    }
} 