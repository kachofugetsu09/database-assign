package com.example.dao;

import com.example.entity.PersonalInfo;
import com.example.util.DBUtil;
import java.sql.*;

public class PersonalInfoDao {
    
    /**
     * 添加个人信息
     */
    public int insert(PersonalInfo personalInfo) {
        String sql = "INSERT INTO personal_info (user_id, department, major, title, office_location) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, personalInfo.getUserId());
            ps.setString(2, personalInfo.getDepartment());
            ps.setString(3, personalInfo.getMajor());
            ps.setString(4, personalInfo.getTitle());
            ps.setString(5, personalInfo.getOfficeLocation());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 更新个人信息
     */
    public int update(PersonalInfo personalInfo) {
        String sql = "UPDATE personal_info SET department = ?, major = ?, title = ?, office_location = ? WHERE user_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setString(1, personalInfo.getDepartment());
            ps.setString(2, personalInfo.getMajor());
            ps.setString(3, personalInfo.getTitle());
            ps.setString(4, personalInfo.getOfficeLocation());
            ps.setLong(5, personalInfo.getUserId());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 根据用户ID查询个人信息
     */
    public PersonalInfo selectByUserId(Long userId) {
        String sql = "SELECT * FROM personal_info WHERE user_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, userId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return extractPersonalInfo(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return null;
    }
    
    /**
     * 从ResultSet中提取PersonalInfo对象
     */
    private PersonalInfo extractPersonalInfo(ResultSet rs) throws SQLException {
        PersonalInfo personalInfo = new PersonalInfo();
        personalInfo.setUserId(rs.getLong("user_id"));
        personalInfo.setDepartment(rs.getString("department"));
        personalInfo.setMajor(rs.getString("major"));
        personalInfo.setTitle(rs.getString("title"));
        personalInfo.setOfficeLocation(rs.getString("office_location"));
        return personalInfo;
    }
}