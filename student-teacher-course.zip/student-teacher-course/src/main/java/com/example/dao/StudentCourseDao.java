package com.example.dao;

import com.example.entity.StudentCourse;
import com.example.util.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentCourseDao {
    
    /**
     * 添加选课记录
     */
    public int insert(StudentCourse studentCourse) {
        String sql = "INSERT INTO student_course (student_id, course_id, create_time) VALUES (?, ?, NOW())";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, studentCourse.getStudentId());
            ps.setLong(2, studentCourse.getCourseId());
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 删除选课记录
     */
    public int delete(Long id) {
        String sql = "DELETE FROM student_course WHERE id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            return ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 根据学生ID和课程ID删除选课记录
     */
    public int deleteByStudentAndCourse(Long studentId, Long courseId) {
        String sql = "DELETE FROM student_course WHERE student_id = ? AND course_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, studentId);
            ps.setLong(2, courseId);
            int result = ps.executeUpdate();
            return result > 0 ? 1 : 0;  // 返回1表示删除成功，0表示没有找到记录
        } catch (SQLException e) {
            e.printStackTrace();
            return 0;
        } finally {
            DBUtil.closeAll(conn, ps, null);
        }
    }
    
    /**
     * 根据ID查询选课记录
     */
    public StudentCourse selectById(Long id) {
        String sql = "SELECT * FROM student_course WHERE id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, id);
            rs = ps.executeQuery();
            if (rs.next()) {
                return extractStudentCourse(rs);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return null;
    }
    
    /**
     * 查询学生的所有选课记录
     */
    public List<StudentCourse> selectByStudentId(Long studentId) {
        String sql = "SELECT * FROM student_course WHERE student_id = ? ORDER BY create_time DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<StudentCourse> studentCourses = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, studentId);
            rs = ps.executeQuery();
            while (rs.next()) {
                studentCourses.add(extractStudentCourse(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return studentCourses;
    }
    
    /**
     * 查询课程的所有选课记录
     */
    public List<StudentCourse> selectByCourseId(Long courseId) {
        String sql = "SELECT * FROM student_course WHERE course_id = ? ORDER BY create_time DESC";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<StudentCourse> studentCourses = new ArrayList<>();
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, courseId);
            rs = ps.executeQuery();
            while (rs.next()) {
                studentCourses.add(extractStudentCourse(rs));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return studentCourses;
    }
    
    /**
     * 检查学生是否已选该课程
     */
    public boolean isStudentEnrolled(Long studentId, Long courseId) {
        String sql = "SELECT COUNT(*) FROM student_course WHERE student_id = ? AND course_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            conn = DBUtil.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setLong(1, studentId);
            ps.setLong(2, courseId);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeAll(conn, ps, rs);
        }
        return false;
    }
    
    /**
     * 从ResultSet中提取StudentCourse对象
     */
    private StudentCourse extractStudentCourse(ResultSet rs) throws SQLException {
        StudentCourse studentCourse = new StudentCourse();
        studentCourse.setId(rs.getLong("id"));
        studentCourse.setStudentId(rs.getLong("student_id"));
        studentCourse.setCourseId(rs.getLong("course_id"));
        studentCourse.setCreateTime(rs.getTimestamp("create_time"));
        return studentCourse;
    }
} 