package com.example.entity;

import lombok.Data;

@Data
public class PersonalInfo {
    private Long userId;
    private String department;    // 院系（针对学生）
    private String major;         // 专业（针对学生）
    private String title;         // 职称（针对教师）
    private String officeLocation; // 办公室位置（针对教师）
} 