package com.example.entity;

import lombok.Data;
import java.sql.Timestamp;

@Data
public class Course {
    private Long id;
    private Long teacherId;
    private String name;
    private String description;
    private String location;
    private Timestamp startTime;
    private Timestamp endTime;
    private String status;
    private Timestamp createTime;
    private Timestamp updateTime;
} 