package com.example.entity;

import lombok.Data;
import java.sql.Timestamp;

@Data
public class User {
    private Long id;
    private String username;
    private String password;
    private String role;  // student, teacher, admin
    private String email;
    private String phone;
    private Timestamp createTime;
    private Timestamp updateTime;
}